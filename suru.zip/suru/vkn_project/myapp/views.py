import os
import time
from django.shortcuts import render, redirect
from .models import *
from django.core.mail import send_mail
from vkn_project.settings import EMAIL_HOST_USER
from django.contrib import messages
import uuid
from django.conf import settings
from django.contrib.auth import authenticate

from django.http import HttpResponse



def register_view(request):
    if request.method=='POST':
        user=request.POST.get('email')
        first_name=request.POST.get('first_name')
        last_name=request.POST.get('last_name')
        ps1=request.POST.get('ps1')
        ps2=request.POST.get('ps2')
        if ps1==ps2:
            if User.objects.filter(username=user).first():
                messages.error(request,'username already taken or exist')
                return redirect(register_view)
            user_obj=User(username=user,first_name=first_name,last_name=last_name)
            user_obj.set_password(ps1)
            user_obj.save()

            auth_token=str(uuid.uuid4())
            a=reg_model.objects.create(user_name=user_obj,token=auth_token)
            a.save()
            email_verification(request,user,auth_token)
            return render(request, 'please_verify.html')


    return render(request,'register.html')


def email_verification(request,user,auth_token):
    subject = 'Verify Your Account'
    message = f"  We're happy you signed up for VKN \n To start exploring VKN please click on the link bleow to verify your email address. http://127.0.0.1:8000/verify_email/{auth_token}"
    sender = EMAIL_HOST_USER
    reciever = [user]
    send_mail(subject, message, sender, reciever)


def login_view(request):
    if request.method=='POST':
        user_name=request.POST.get('user_name')
        ps=request.POST.get('password')
        user_obj=User.objects.filter(username=user_name).first()
        if user_obj is None:
            messages.success(request,'User not found  !!!!\n Please check the details you entered')
            return redirect(login_view)
        b=reg_model.objects.get(user_name=user_obj)
        if not b.is_verified:
            messages.warning(request,'Profile is not verified ,please verify before log in')
            return redirect(login_view)
        user=authenticate(username=user_name,password=ps)
        if user is None:
            messages.success(request,'wrong password or username')
            return redirect(login_view)

        profile=reg_model.objects.get(user_name=user)
        return render(request,'profile_page.html',{'x':profile})


    return render(request, 'login.html')


def verification(request,token):
    a=reg_model.objects.get(token=token)
    if a:
        if a.is_verified:
            messages.success(request,'Profile already verified,Please Login to continue')
            return redirect(login_view)
        else:
            a.is_verified=True
            a.save()
            messages.success(request,'Thank you for registering with us,Please login to continue')
            return redirect(login_view)
    else:
        return render(request,'error.html')


def edit_profile(request,token):
    if request.method=='POST':
        a = reg_model.objects.get(token=token)
        a.user_name.username = request.POST.get('username')
        a.user_name.first_name = request.POST.get('first_name')
        a.user_name.last_name = request.POST.get('last_name')

        a.user_name.save()

        a.save()
        b = reg_model.objects.get(token=token)

        messages.success(request, f'your profile updated successfully')
        return render(request, 'profile_page.html', {'x': b})
    b = reg_model.objects.get(token=token)
    return render(request,'edit_profile.html',{'x':b})


def home(request):
    return render(request,'home.html')