from django.urls import path
from .views import *

urlpatterns=[

   path('login/',login_view,name='login'),
   path('register/',register_view,name='register'),
   path('verify_email/<str:token>',verification,name='verification'),
   path('edit_profile/<str:token>',edit_profile,name='edit_profile'),
   path('',home,name='home')


]